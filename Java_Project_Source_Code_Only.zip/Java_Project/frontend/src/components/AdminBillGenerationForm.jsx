import React, { useState, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';

export const AdminBillGenerationForm = () => {
  const { customers, generateBill } = useApp();

  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [formData, setFormData] = useState({
    customerId: '',
    billingMonth: '',
    currentReading: '',
    dueDate: '',
  });

  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [validationErrors, setValidationErrors] = useState({});

  const [liveBreakdown, setLiveBreakdown] = useState({
    unitsConsumed: 0,
    baseCharge: 10.00,
    tier1Cost: 0,
    tier2Cost: 0,
    tier3Cost: 0,
    subtotal: 10.00,
    tax: 0.50,
    total: 10.50,
  });

  const handleCustomerChange = (e) => {
    const customerId = e.target.value;
    const customer = customers.find((c) => c.id.toString() === customerId) || null;
    
    setSelectedCustomer(customer);
    setFormData((prev) => ({
      ...prev,
      customerId,
      currentReading: '',
    }));
    
    if (validationErrors.customerId) {
      setValidationErrors((prev) => {
        const copy = { ...prev };
        delete copy.customerId;
        return copy;
      });
    }
  };

  useEffect(() => {
    if (!selectedCustomer || !formData.currentReading) {
      setLiveBreakdown({
        unitsConsumed: 0,
        baseCharge: 10.00,
        tier1Cost: 0,
        tier2Cost: 0,
        tier3Cost: 0,
        subtotal: 10.00,
        tax: 0.50,
        total: 10.50,
      });
      return;
    }

    const currentVal = parseFloat(formData.currentReading);
    const previousVal = selectedCustomer.lastReading;

    if (isNaN(currentVal) || currentVal < previousVal) {
      return;
    }

    const units = currentVal - previousVal;
    const BASE_CHARGE = 10.00;
    let t1 = 0;
    let t2 = 0;
    let t3 = 0;

    if (units <= 100) {
      t1 = units * 0.12;
    } else if (units <= 300) {
      t1 = 100 * 0.12;
      t2 = (units - 100) * 0.18;
    } else {
      t1 = 100 * 0.12;
      t2 = 200 * 0.18;
      t3 = (units - 300) * 0.25;
    }

    const sub = BASE_CHARGE + t1 + t2 + t3;
    const tax = sub * 0.05;
    const tot = sub + tax;

    setLiveBreakdown({
      unitsConsumed: parseFloat(units.toFixed(2)),
      baseCharge: BASE_CHARGE,
      tier1Cost: parseFloat(t1.toFixed(2)),
      tier2Cost: parseFloat(t2.toFixed(2)),
      tier3Cost: parseFloat(t3.toFixed(2)),
      subtotal: parseFloat(sub.toFixed(2)),
      tax: parseFloat(tax.toFixed(2)),
      total: parseFloat(tot.toFixed(2)),
    });
  }, [formData.currentReading, selectedCustomer]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    if (validationErrors[name]) {
      setValidationErrors((prev) => {
        const copy = { ...prev };
        delete copy[name];
        return copy;
      });
    }
  };

  const validateForm = () => {
    const errors = {};
    
    if (!formData.customerId) errors.customerId = 'Please select a customer profile';
    if (!formData.billingMonth) errors.billingMonth = 'Please select a billing month';
    
    if (!formData.currentReading) {
      errors.currentReading = 'Current meter reading is required';
    } else {
      const cur = parseFloat(formData.currentReading);
      if (isNaN(cur) || cur < 0) {
        errors.currentReading = 'Reading must be a positive number';
      } else if (selectedCustomer && cur < selectedCustomer.lastReading) {
        errors.currentReading = `Current reading must be higher than previous reading (${selectedCustomer.lastReading} kWh)`;
      }
    }

    if (!formData.dueDate) {
      errors.dueDate = 'Due date is required';
    } else {
      const selectedDate = new Date(formData.dueDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (selectedDate < today) {
        errors.dueDate = 'Due date must be in the future';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccessMessage(null);
    setErrorMessage(null);

    if (!validateForm()) return;

    setLoading(true);

    try {
      generateBill(
        parseInt(formData.customerId, 10),
        formData.billingMonth,
        parseFloat(formData.currentReading),
        formData.dueDate
      );
      
      setSuccessMessage(
        `Success! Bill has been generated for ${selectedCustomer?.fullName}. Simulated notification is queued.`
      );
      
      setFormData((prev) => ({
        ...prev,
        currentReading: '',
        dueDate: '',
      }));

    } catch (error) {
      console.error(error);
      setErrorMessage(error.message || 'Failed to generate bill.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full bg-slate-900/60 border border-slate-800/80 rounded-2xl p-6 md:p-8 backdrop-blur-md shadow-2xl">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Form Controls */}
        <form onSubmit={handleSubmit} className="lg:col-span-7 space-y-6">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-xl font-bold text-slate-100">Billing Input Details</h3>
            <p className="text-slate-400 text-xs mt-1">Provide monthly meter data to generate invoice.</p>
          </div>
          
          {/* Customer Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Select Customer Account
            </label>
            <select
              name="customerId"
              value={formData.customerId}
              onChange={handleCustomerChange}
              disabled={loading}
              className={`w-full bg-slate-950/60 border ${
                validationErrors.customerId ? 'border-red-500' : 'border-slate-800'
              } rounded-xl px-4 py-3 text-slate-200 outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200`}
            >
              <option value="">-- Choose Customer --</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.fullName} ({c.connectionNumber})
                </option>
              ))}
            </select>
            {validationErrors.customerId && (
              <p className="text-red-400 text-xs mt-1.5 font-medium">{validationErrors.customerId}</p>
            )}
          </div>

          {/* Connected Meter Information Banner */}
          {selectedCustomer && (
            <div className="bg-slate-950/40 border border-indigo-950/60 rounded-xl p-4 grid grid-cols-2 gap-4 text-xs shadow-inner animate-fadeIn">
              <div>
                <span className="text-slate-500 block uppercase tracking-wider font-semibold">Meter ID</span>
                <span className="text-slate-300 font-mono text-sm">{selectedCustomer.meterNumber}</span>
              </div>
              <div>
                <span className="text-slate-500 block uppercase tracking-wider font-semibold">Address</span>
                <span className="text-slate-300 text-sm truncate block">{selectedCustomer.address}</span>
              </div>
            </div>
          )}

          {/* Month & Readings grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Billing Month */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Billing Month
              </label>
              <input
                type="month"
                name="billingMonth"
                value={formData.billingMonth}
                onChange={handleInputChange}
                disabled={loading}
                className={`w-full bg-slate-950/60 border ${
                  validationErrors.billingMonth ? 'border-red-500' : 'border-slate-800'
                } rounded-xl px-4 py-2.5 text-slate-200 outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200`}
              />
              {validationErrors.billingMonth && (
                <p className="text-red-400 text-xs mt-1.5 font-medium">{validationErrors.billingMonth}</p>
              )}
            </div>

            {/* Due Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Due Date
              </label>
              <input
                type="date"
                name="dueDate"
                value={formData.dueDate}
                onChange={handleInputChange}
                disabled={loading}
                className={`w-full bg-slate-950/60 border ${
                  validationErrors.dueDate ? 'border-red-500' : 'border-slate-800'
                } rounded-xl px-4 py-2.5 text-slate-200 outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200`}
              />
              {validationErrors.dueDate && (
                <p className="text-red-400 text-xs mt-1.5 font-medium">{validationErrors.dueDate}</p>
              )}
            </div>
          </div>

          {/* Meter Readings Column */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Previous Reading */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Previous Reading (kWh)
              </label>
              <input
                type="text"
                readOnly
                value={selectedCustomer ? `${selectedCustomer.lastReading.toFixed(2)} kWh` : 'Select customer...'}
                className="w-full bg-slate-950/30 border border-slate-900 text-slate-500 rounded-xl px-4 py-2.5 text-sm font-mono cursor-not-allowed select-none"
              />
            </div>

            {/* Current Reading */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Current Reading (kWh)
              </label>
              <input
                type="number"
                name="currentReading"
                placeholder="e.g. 1350.50"
                step="0.01"
                value={formData.currentReading}
                onChange={handleInputChange}
                disabled={!selectedCustomer || loading}
                className={`w-full bg-slate-950/60 border ${
                  validationErrors.currentReading ? 'border-red-500' : 'border-slate-800'
                } rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200`}
              />
              {validationErrors.currentReading && (
                <p className="text-red-400 text-xs mt-1.5 font-medium">{validationErrors.currentReading}</p>
              )}
            </div>
          </div>

          {/* Success / Error Feedback panels */}
          {successMessage && (
            <div className="bg-emerald-950/40 border border-emerald-900/60 text-emerald-300 p-4 rounded-xl text-sm flex items-start space-x-2.5 animate-fadeIn">
              <span className="text-base">✓</span>
              <span>{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="bg-red-950/40 border border-red-900/60 text-red-300 p-4 rounded-xl text-sm flex items-start space-x-2.5 animate-fadeIn">
              <span className="text-base">⚠</span>
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-600 hover:from-cyan-600 hover:via-indigo-600 hover:to-purple-700 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-40 disabled:pointer-events-none"
          >
            {loading ? 'Processing...' : 'Generate & Save Bill'}
          </button>

        </form>

        {/* Right Side: Live Estimation Summary Panel */}
        <div className="lg:col-span-5 bg-slate-950/70 border border-slate-800/80 rounded-2xl p-6 h-full flex flex-col justify-between shadow-xl">
          <div>
            <h3 className="text-md font-bold text-slate-200 mb-4 flex items-center space-x-2">
              <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse"></span>
              <span>Live Pricing Estimation</span>
            </h3>
            
            <div className="space-y-4">
              
              {/* Readings Summary */}
              <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-850 space-y-2">
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Units Consumed</span>
                  <span className="font-semibold text-slate-300 font-mono">{liveBreakdown.unitsConsumed.toFixed(2)} kWh</span>
                </div>
                <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-cyan-400 to-indigo-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min((liveBreakdown.unitsConsumed / 500) * 100, 100)}%` }}
                  />
                </div>
              </div>

              {/* Line items list */}
              <div className="text-sm space-y-3.5 px-1">
                <div className="flex justify-between text-slate-400">
                  <span>Base Charge</span>
                  <span className="font-mono text-slate-200">${liveBreakdown.baseCharge.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-slate-400">
                  <div className="flex flex-col">
                    <span>Tier 1 (0-100 kWh)</span>
                    <span className="text-slate-600 text-[10px]">@ $0.12/kWh</span>
                  </div>
                  <span className="font-mono text-slate-200">${liveBreakdown.tier1Cost.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-slate-400">
                  <div className="flex flex-col">
                    <span>Tier 2 (101-300 kWh)</span>
                    <span className="text-slate-600 text-[10px]">@ $0.18/kWh</span>
                  </div>
                  <span className="font-mono text-slate-200">${liveBreakdown.tier2Cost.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-slate-400">
                  <div className="flex flex-col">
                    <span>Tier 3 (301+ kWh)</span>
                    <span className="text-slate-600 text-[10px]">@ $0.25/kWh</span>
                  </div>
                  <span className="font-mono text-slate-200">${liveBreakdown.tier3Cost.toFixed(2)}</span>
                </div>

                <div className="border-t border-slate-800/80 my-2 pt-2 flex justify-between text-slate-300">
                  <span>Subtotal</span>
                  <span className="font-mono font-semibold">${liveBreakdown.subtotal.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-slate-400">
                  <div className="flex items-center space-x-1.5">
                    <span>Utility Tax</span>
                    <span className="bg-slate-900 border border-slate-850 text-[10px] text-cyan-400 px-1.5 py-0.5 rounded-full font-medium">5.0%</span>
                  </div>
                  <span className="font-mono text-slate-200">${liveBreakdown.tax.toFixed(2)}</span>
                </div>

              </div>

            </div>
          </div>

          {/* Grand Total glowing section */}
          <div className="mt-8 border-t border-slate-800/80 pt-6">
            <div className="bg-indigo-950/20 border border-indigo-900/30 p-4 rounded-xl text-center shadow-lg">
              <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold block mb-1">
                Projected Total Invoice
              </span>
              <span className="text-3xl font-extrabold text-white font-mono bg-gradient-to-r from-cyan-400 to-indigo-400 bg-clip-text text-transparent">
                ${liveBreakdown.total.toFixed(2)}
              </span>
            </div>
            <p className="text-[10px] text-slate-655 mt-3 text-center">
              * Exact calculations match JVM engine specifications.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
};

export default AdminBillGenerationForm;
