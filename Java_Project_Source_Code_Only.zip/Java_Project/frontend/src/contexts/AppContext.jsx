import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  getCustomers, getBills, getReadings, getPayments, getNotifications,
  mockGenerateBill, mockPayBill, initMockDb
} from '../utils/mockDb';

const AppContext = createContext(undefined);

export const AppProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [bills, setBills] = useState([]);
  const [payments, setPayments] = useState([]);
  const [notificationsLog, setNotificationsLog] = useState([]);
  const [activeNotification, setActiveNotification] = useState(null);

  const refreshData = () => {
    setCustomers(getCustomers());
    setBills(getBills());
    setPayments(getPayments());
    setNotificationsLog(getNotifications());
  };

  useEffect(() => {
    initMockDb();
    refreshData();

    const token = localStorage.getItem('accessToken');
    const role = localStorage.getItem('userRole');
    const email = localStorage.getItem('userEmail');
    if (token && role && email) {
      setUser({ email, role });
    }

    const handleNotification = (e) => {
      setActiveNotification(e.detail);
      refreshData();
    };

    const handleSessionExpired = () => {
      logout();
    };

    window.addEventListener('notification-dispatched', handleNotification);
    window.addEventListener('auth-session-expired', handleSessionExpired);

    return () => {
      window.removeEventListener('notification-dispatched', handleNotification);
      window.removeEventListener('auth-session-expired', handleSessionExpired);
    };
  }, []);

  const login = (email, role) => {
    const mockToken = 'JWT-TOKEN-MOCK-' + Math.random().toString(36).substring(7);
    localStorage.setItem('accessToken', mockToken);
    localStorage.setItem('userRole', role);
    localStorage.setItem('userEmail', email);
    
    setUser({ email, role });
    refreshData();
    return true;
  };

  const logout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('userRole');
    localStorage.removeItem('userEmail');
    setUser(null);
  };

  const generateBill = (customerId, month, current, due) => {
    mockGenerateBill(customerId, month, current, due);
    refreshData();
  };

  const payBill = (billId, method) => {
    const payment = mockPayBill(billId, method);
    refreshData();
    return payment;
  };

  const clearActiveNotification = () => {
    setActiveNotification(null);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        customers,
        bills,
        payments,
        notificationsLog,
        activeNotification,
        clearActiveNotification,
        login,
        logout,
        generateBill,
        payBill,
        refreshData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
export default AppContext;
