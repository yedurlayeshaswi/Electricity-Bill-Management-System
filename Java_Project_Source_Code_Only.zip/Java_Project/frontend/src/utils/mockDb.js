// Local Storage Database Mocking helper
// Mimics PostgreSQL/MySQL schema state & Spring Boot controller operations on client side

const INITIAL_CUSTOMERS = [
  {
    id: 101,
    userId: 2,
    fullName: 'Alexander Wright',
    connectionNumber: 'CON-8839-202X',
    address: '742 Evergreen Terrace, Springfield',
    meterNumber: 'MTR-994827',
    lastReading: 1250.50,
  },
  {
    id: 102,
    userId: 3,
    fullName: 'Sophia Mercer',
    connectionNumber: 'CON-4729-105Y',
    address: '10880 Wilshire Blvd, Los Angeles, CA',
    meterNumber: 'MTR-338271',
    lastReading: 3420.00,
  },
  {
    id: 103,
    userId: 4,
    fullName: 'Marcus Vance',
    connectionNumber: 'CON-3049-772Z',
    address: '221B Baker St, London, NW1 6XE',
    meterNumber: 'MTR-884930',
    lastReading: 890.75,
  },
];

const INITIAL_READINGS = [
  {
    id: 1,
    customerId: 101,
    readingDate: '2026-05-15',
    previousReading: 1100.00,
    currentReading: 1250.50,
    totalUnits: 150.50,
  },
  {
    id: 2,
    customerId: 102,
    readingDate: '2026-05-15',
    previousReading: 3200.00,
    currentReading: 3420.00,
    totalUnits: 220.00,
  },
  {
    id: 3,
    customerId: 103,
    readingDate: '2026-05-15',
    previousReading: 800.00,
    currentReading: 890.75,
    totalUnits: 90.75,
  },
];

const INITIAL_BILLS = [
  {
    id: 5001,
    customerId: 101,
    customerName: 'Alexander Wright',
    connectionNumber: 'CON-8839-202X',
    meterNumber: 'MTR-994827',
    readingId: 1,
    billingMonth: '2026-05',
    amountDue: 31.09,
    taxAmount: 1.55,
    totalAmount: 32.64,
    dueDate: '2026-06-15',
    status: 'PAID',
  },
  {
    id: 5002,
    customerId: 102,
    customerName: 'Sophia Mercer',
    connectionNumber: 'CON-4729-105Y',
    meterNumber: 'MTR-338271',
    readingId: 2,
    billingMonth: '2026-05',
    amountDue: 43.60,
    taxAmount: 2.18,
    totalAmount: 45.78,
    dueDate: '2026-06-15',
    status: 'UNPAID',
  },
];

export const initMockDb = () => {
  if (!localStorage.getItem('electricity_db_initialized')) {
    localStorage.setItem('customers', JSON.stringify(INITIAL_CUSTOMERS));
    localStorage.setItem('readings', JSON.stringify(INITIAL_READINGS));
    localStorage.setItem('bills', JSON.stringify(INITIAL_BILLS));
    localStorage.setItem('payments', JSON.stringify([]));
    localStorage.setItem('notifications', JSON.stringify([]));
    localStorage.setItem('electricity_db_initialized', 'true');
  }
};

export const getCustomers = () => {
  initMockDb();
  return JSON.parse(localStorage.getItem('customers') || '[]');
};

export const getBills = () => {
  initMockDb();
  return JSON.parse(localStorage.getItem('bills') || '[]');
};

export const getReadings = () => {
  initMockDb();
  return JSON.parse(localStorage.getItem('readings') || '[]');
};

export const getPayments = () => {
  initMockDb();
  return JSON.parse(localStorage.getItem('payments') || '[]');
};

export const getNotifications = () => {
  initMockDb();
  return JSON.parse(localStorage.getItem('notifications') || '[]');
};

// Generates a bill (mimics BillCalculationService.java in pure JS)
export const mockGenerateBill = (customerId, billingMonth, currentReadingVal, dueDate) => {
  const customers = getCustomers();
  const readings = getReadings();
  const bills = getBills();

  const customerIndex = customers.findIndex((c) => c.id === customerId);
  if (customerIndex === -1) throw new Error('Customer profile not found');

  const customer = customers[customerIndex];
  const lastReading = customer.lastReading;

  if (currentReadingVal < lastReading) {
    throw new Error(`Current reading must be higher than previous reading (${lastReading} kWh)`);
  }

  const duplicate = bills.some((b) => b.customerId === customerId && b.billingMonth === billingMonth);
  if (duplicate) {
    throw new Error(`A bill already exists for customer in billing month ${billingMonth}`);
  }

  const units = currentReadingVal - lastReading;

  const BASE_CHARGE = 10.00;
  let t1 = 0;
  let t2 = 0;
  let t3 = 0;

  if (units <= 100) {
    t1 = units * 0.12;
  } else if (units <= 300) {
    t1 = 100 * 0.12;
    t2 = (units - 100) * 0.18;
  } else {
    t1 = 100 * 0.12;
    t2 = 200 * 0.18;
    t3 = (units - 300) * 0.25;
  }

  const amountDue = parseFloat((BASE_CHARGE + t1 + t2 + t3).toFixed(2));
  const taxAmount = parseFloat((amountDue * 0.05).toFixed(2));
  const totalAmount = parseFloat((amountDue + taxAmount).toFixed(2));

  const newReading = {
    id: readings.length + 1,
    customerId,
    readingDate: new Date().toISOString().split('T')[0],
    previousReading: lastReading,
    currentReading: currentReadingVal,
    totalUnits: parseFloat(units.toFixed(2)),
  };

  const newBill = {
    id: 5000 + bills.length + 1,
    customerId,
    customerName: customer.fullName,
    connectionNumber: customer.connectionNumber,
    meterNumber: customer.meterNumber,
    readingId: newReading.id,
    billingMonth,
    amountDue,
    taxAmount,
    totalAmount,
    dueDate,
    status: 'UNPAID',
  };

  customers[customerIndex].lastReading = currentReadingVal;

  localStorage.setItem('customers', JSON.stringify(customers));
  localStorage.setItem('readings', JSON.stringify([...readings, newReading]));
  localStorage.setItem('bills', JSON.stringify([...bills, newBill]));

  mockAsyncNotification(
    'customer@utility.com',
    '⚡ New Electricity Bill Generated',
    `Hello ${customer.fullName}, a new bill of $${totalAmount.toFixed(2)} has been generated for month ${billingMonth}. Due date: ${dueDate}.`
  );

  return newBill;
};

// Processes mock payment & triggers async email
export const mockPayBill = (billId, method) => {
  const bills = getBills();
  const payments = getPayments();

  const billIndex = bills.findIndex((b) => b.id === billId);
  if (billIndex === -1) throw new Error('Bill not found');
  if (bills[billIndex].status === 'PAID') throw new Error('Bill is already paid');

  const txRef = 'TXN-' + Math.random().toString(36).substring(2, 11).toUpperCase();

  const newPayment = {
    id: payments.length + 1,
    billId,
    paymentDate: new Date().toISOString(),
    transactionReference: txRef,
    amountPaid: bills[billIndex].totalAmount,
    paymentMethod: method,
  };

  bills[billIndex].status = 'PAID';

  localStorage.setItem('bills', JSON.stringify(bills));
  localStorage.setItem('payments', JSON.stringify([...payments, newPayment]));

  mockAsyncNotification(
    'customer@utility.com',
    '💳 Payment Receipt Confirmation',
    `Thank you! We received your payment of $${newPayment.amountPaid.toFixed(2)} using ${method} for Bill Ref #${billId}. Tx Reference: ${txRef}.`
  );

  return newPayment;
};

const mockAsyncNotification = (email, title, body) => {
  const notifications = getNotifications();
  const newNotif = {
    id: notifications.length + 1,
    timestamp: new Date().toLocaleTimeString(),
    recipient: email,
    title,
    body,
    status: 'PENDING',
  };

  localStorage.setItem('notifications', JSON.stringify([...notifications, newNotif]));

  setTimeout(() => {
    const activeNotifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    const index = activeNotifications.findIndex((n) => n.id === newNotif.id);
    if (index !== -1) {
      activeNotifications[index].status = 'SENT';
      localStorage.setItem('notifications', JSON.stringify(activeNotifications));
      window.dispatchEvent(new CustomEvent('notification-dispatched', { detail: activeNotifications[index] }));
    }
  }, 2500);
};
