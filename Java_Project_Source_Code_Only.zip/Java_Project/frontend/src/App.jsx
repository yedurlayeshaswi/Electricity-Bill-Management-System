import React, { useEffect } from 'react';
import { useApp } from './contexts/AppContext';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import CustomerDashboard from './pages/CustomerDashboard';
import { Mail, X } from 'lucide-react';

const AppContent = () => {
  const { user, activeNotification, clearActiveNotification } = useApp();

  useEffect(() => {
    if (activeNotification) {
      const timer = setTimeout(() => {
        clearActiveNotification();
      }, 6000);
      return () => clearTimeout(timer);
    }
  }, [activeNotification, clearActiveNotification]);

  const renderRoute = () => {
    if (!user) {
      return <Login />;
    }
    if (user.role === 'ROLE_ADMIN') {
      return <AdminDashboard />;
    }
    return <CustomerDashboard />;
  };

  return (
    <div className="relative min-h-screen bg-slate-950">
      {renderRoute()}

      {activeNotification && (
        <div className="fixed bottom-6 right-6 z-50 w-full max-w-sm bg-slate-900 border border-indigo-500/30 rounded-2xl p-4 shadow-2xl glow-indigo animate-fadeIn transform transition-transform duration-300">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-indigo-950/40 border border-indigo-500/20 rounded-xl text-indigo-400">
                <Mail className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider font-mono">
                  [MOCK-SMTP-DAEMON] Dispatched Alert
                </span>
                <h4 className="text-xs font-black text-slate-100 mt-0.5 truncate">{activeNotification.title}</h4>
              </div>
            </div>
            
            <button
              onClick={clearActiveNotification}
              className="text-slate-500 hover:text-slate-350 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="mt-3 text-[11px] text-slate-400 border-t border-slate-850 pt-2 leading-relaxed">
            {activeNotification.body}
          </div>
        </div>
      )}
    </div>
  );
};

export const App = () => {
  return (
    <React.StrictMode>
      <AppContent />
    </React.StrictMode>
  );
};

export default App;
