import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Shield, User, Lock, Mail, Zap, FileText, MapPin } from 'lucide-react';
import { getCustomers } from '../utils/mockDb';

export const Login = () => {
  const { login } = useApp();
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  // Login Form States
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Register Form States
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConnection, setRegConnection] = useState('');
  const [regMeter, setRegMeter] = useState('');
  const [regAddress, setRegAddress] = useState('');
  const [regReading, setRegReading] = useState('');

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    // Check custom registrations in localStorage users database
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const matchedUser = users.find(u => u.email === email && u.password === password);

    if (email === 'admin@utility.com' && password === 'admin') {
      login(email, 'ROLE_ADMIN');
    } else if (email === 'customer@utility.com' && password === 'customer') {
      login(email, 'ROLE_CUSTOMER');
    } else if (matchedUser) {
      login(matchedUser.email, matchedUser.role);
    } else {
      setError('Invalid credentials. Double check details or use shortcuts.');
    }
  };

  const handleRegisterSubmit = (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!regName || !regEmail || !regPassword || !regConnection || !regMeter || !regAddress) {
      setError('Please fill in all required fields');
      return;
    }

    const customers = getCustomers();
    const users = JSON.parse(localStorage.getItem('users') || '[]');

    // Check for duplicates
    if (users.some(u => u.email === regEmail) || regEmail === 'customer@utility.com' || regEmail === 'admin@utility.com') {
      setError('A user account with this email already exists.');
      return;
    }

    if (customers.some(c => c.connectionNumber === regConnection || c.meterNumber === regMeter)) {
      setError('Connection Number or Meter Number already registered.');
      return;
    }

    const newUserId = 10 + users.length;
    const newProfileId = 200 + customers.length;

    const newUser = {
      id: newUserId,
      email: regEmail,
      password: regPassword,
      role: 'ROLE_CUSTOMER',
      profileId: newProfileId
    };

    const newCustomer = {
      id: newProfileId,
      userId: newUserId,
      fullName: regName,
      connectionNumber: regConnection,
      address: regAddress,
      meterNumber: regMeter,
      lastReading: parseFloat(regReading) || 0.00
    };

    // Save to simulated mock storage
    localStorage.setItem('users', JSON.stringify([...users, newUser]));
    localStorage.setItem('customers', JSON.stringify([...customers, newCustomer]));

    setSuccess(`Registration successful! You can now log in using ${regEmail}`);
    setIsRegistering(false);
    
    // Auto-populate login inputs
    setEmail(regEmail);
    setPassword(regPassword);

    // Clear inputs
    setRegName('');
    setRegEmail('');
    setRegPassword('');
    setRegConnection('');
    setRegMeter('');
    setRegAddress('');
    setRegReading('');
  };

  const handleQuickLogin = (role) => {
    setError(null);
    setSuccess(null);
    if (role === 'admin') {
      login('admin@utility.com', 'ROLE_ADMIN');
    } else {
      login('customer@utility.com', 'ROLE_CUSTOMER');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4 relative overflow-hidden py-12">
      {/* Background radial highlights */}
      <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl" />

      {/* Auth Card */}
      <div className="w-full max-w-lg glass rounded-3xl p-8 border border-slate-800 shadow-2xl relative z-10 transform transition-all duration-300 hover:border-slate-700/60">
        
        {/* Header */}
        <div className="text-center mb-6">
          <div className="mx-auto w-12 h-12 bg-gradient-to-tr from-cyan-400 to-indigo-500 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20 mb-3 animate-pulse">
            <Zap className="h-6 w-6 text-slate-950 fill-slate-950 stroke-[1.5]" />
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">VoltStream</h1>
          <p className="text-slate-400 text-xs mt-1">Electricity Bill Management Portal</p>
        </div>

        {error && (
          <div className="mb-5 bg-red-950/40 border border-red-900/50 text-red-300 px-4 py-3 rounded-xl text-xs flex items-center space-x-2 animate-fadeIn">
            <span>⚠</span>
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-5 bg-emerald-950/40 border border-emerald-900/50 text-emerald-300 px-4 py-3 rounded-xl text-xs flex items-center space-x-2 animate-fadeIn">
            <span>✓</span>
            <span>{success}</span>
          </div>
        )}

        {/* LOGIN SCREEN */}
        {!isRegistering ? (
          <div className="space-y-5">
            <form onSubmit={handleLoginSubmit} className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-500">
                    <Mail className="h-4 w-4" />
                  </span>
                  <input
                    type="email"
                    required
                    placeholder="email@utility.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-2.5 outline-none text-slate-200 text-sm transition focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  Password
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-500">
                    <Lock className="h-4 w-4" />
                  </span>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-800 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-2.5 outline-none text-slate-200 text-sm transition focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-600 hover:from-cyan-600 hover:via-indigo-600 hover:to-purple-700 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-indigo-950 transition transform active:scale-98 cursor-pointer"
              >
                Log In
              </button>
            </form>

            <div className="text-center">
              <span className="text-slate-400 text-xs">Don't have an account? </span>
              <button
                onClick={() => { setIsRegistering(true); setError(null); }}
                className="text-xs text-cyan-400 font-bold hover:underline transition cursor-pointer"
              >
                Register Connection
              </button>
            </div>

            {/* Quick Access logins */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-850" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-slate-950/80 px-3 text-slate-500">Quick Sandbox Access</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => handleQuickLogin('admin')}
                className="flex items-center justify-center space-x-2 py-2.5 px-3 bg-slate-900/60 border border-slate-800 hover:border-cyan-500/50 hover:bg-slate-900 rounded-xl text-xs font-semibold text-slate-300 transition cursor-pointer"
              >
                <Shield className="h-4 w-4 text-cyan-400" />
                <span>Admin View</span>
              </button>
              
              <button
                onClick={() => handleQuickLogin('customer')}
                className="flex items-center justify-center space-x-2 py-2.5 px-3 bg-slate-900/60 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-900 rounded-xl text-xs font-semibold text-slate-300 transition cursor-pointer"
              >
                <User className="h-4 w-4 text-indigo-400" />
                <span>Customer View</span>
              </button>
            </div>
          </div>
        ) : (
          /* REGISTRATION SCREEN */
          <form onSubmit={handleRegisterSubmit} className="space-y-4 animate-fadeIn">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Full Name
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                    <User className="h-3.5 w-3.5" />
                  </span>
                  <input
                    type="text"
                    required
                    placeholder="Jane Doe"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-2 outline-none text-slate-200 text-xs transition"
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Email
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                    <Mail className="h-3.5 w-3.5" />
                  </span>
                  <input
                    type="email"
                    required
                    placeholder="jane@example.com"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-2 outline-none text-slate-200 text-xs transition"
                  />
                </div>
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                  <Lock className="h-3.5 w-3.5" />
                </span>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  className="w-full bg-slate-900/50 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-2 outline-none text-slate-200 text-xs transition"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Connection Number */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Connection Number
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                    <FileText className="h-3.5 w-3.5" />
                  </span>
                  <input
                    type="text"
                    required
                    placeholder="CON-1234-567A"
                    value={regConnection}
                    onChange={(e) => setRegConnection(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-2 outline-none text-slate-200 text-xs transition"
                  />
                </div>
              </div>

              {/* Meter Serial */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Meter Serial
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                    <Zap className="h-3.5 w-3.5" />
                  </span>
                  <input
                    type="text"
                    required
                    placeholder="MTR-994827"
                    value={regMeter}
                    onChange={(e) => setRegMeter(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-2 outline-none text-slate-200 text-xs transition"
                  />
                </div>
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Billing Address
              </label>
              <div className="relative">
                <span className="absolute inset-y-2 left-0 pl-3 flex items-start text-slate-500">
                  <MapPin className="h-3.5 w-3.5" />
                </span>
                <textarea
                  required
                  rows={2}
                  placeholder="Street Address, City, State, ZIP"
                  value={regAddress}
                  onChange={(e) => setRegAddress(e.target.value)}
                  className="w-full bg-slate-900/50 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-2 outline-none text-slate-200 text-xs transition resize-none"
                />
              </div>
            </div>

            {/* Initial Meter reading */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Initial Meter Reading (kWh)
              </label>
              <input
                type="number"
                placeholder="e.g. 0.00"
                step="0.01"
                value={regReading}
                onChange={(e) => setRegReading(e.target.value)}
                className="w-full bg-slate-900/50 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 outline-none text-slate-200 text-xs transition"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-600 hover:to-indigo-700 text-white font-bold py-3 px-4 rounded-xl shadow-lg transition transform active:scale-98 cursor-pointer text-sm"
            >
              Register Connection
            </button>

            <div className="text-center pt-2">
              <span className="text-slate-400 text-xs">Already have an account? </span>
              <button
                type="button"
                onClick={() => { setIsRegistering(false); setError(null); }}
                className="text-xs text-cyan-400 font-bold hover:underline transition cursor-pointer"
              >
                Log In
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};

export default Login;
