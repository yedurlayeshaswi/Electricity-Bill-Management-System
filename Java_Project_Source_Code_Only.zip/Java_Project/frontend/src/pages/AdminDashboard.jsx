import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { AdminBillGenerationForm } from '../components/AdminBillGenerationForm';
import { Users, FileText, Zap, DollarSign, LogOut, Terminal, CheckCircle2, Clock } from 'lucide-react';

export const AdminDashboard = () => {
  const { logout, user, customers, bills, notificationsLog } = useApp();
  const [showLogs, setShowLogs] = useState(false);

  const totalCustomers = customers.length;
  const totalBills = bills.length;
  const paidBillsCount = bills.filter(b => b.status === 'PAID').length;
  
  const totalRevenue = bills
    .filter(b => b.status === 'PAID')
    .reduce((sum, b) => sum + b.totalAmount, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Navbar */}
      <nav className="glass border-b border-slate-800/80 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 bg-gradient-to-tr from-cyan-400 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/10">
            <Zap className="h-5 w-5 text-slate-950 fill-slate-950 stroke-[1.5]" />
          </div>
          <div>
            <span className="font-extrabold text-white tracking-tight text-lg">VoltStream</span>
            <span className="ml-2.5 bg-cyan-500/15 text-cyan-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-cyan-500/20">
              ROLE_ADMIN
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <span className="text-slate-400 text-sm hidden md:inline">{user?.email}</span>
          <button
            onClick={() => setShowLogs(!showLogs)}
            className="flex items-center space-x-2 py-2 px-4 rounded-xl border border-slate-800 hover:border-slate-700 bg-slate-900/40 text-xs font-semibold text-slate-300 transition-all cursor-pointer"
          >
            <Terminal className="h-4 w-4 text-indigo-400" />
            <span>SMTP Server Logs ({notificationsLog.filter(n => n.status === 'SENT').length})</span>
          </button>
          <button
            onClick={logout}
            className="flex items-center space-x-1.5 py-2 px-4 text-xs font-bold bg-slate-900 border border-slate-800 hover:border-red-500/50 hover:bg-red-950/20 hover:text-red-300 rounded-xl transition-all cursor-pointer"
          >
            <LogOut className="h-4 w-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </nav>

      {/* Main dashboard content */}
      <main className="flex-1 p-6 md:p-8 max-w-7xl w-full mx-auto space-y-8 animate-fadeIn">
        
        {/* Stats Grid */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 hover:border-cyan-500/30 transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-cyan-500/5 group">
            <div className="flex justify-between items-center">
              <span className="text-xs font-semibold uppercase text-slate-500 tracking-wider">Total Customers</span>
              <div className="p-2.5 bg-cyan-950/30 border border-cyan-800/20 rounded-xl text-cyan-400 group-hover:scale-110 transition-transform">
                <Users className="h-5 w-5" />
              </div>
            </div>
            <div className="mt-4">
              <span className="text-3xl font-extrabold font-mono">{totalCustomers}</span>
              <span className="text-xs block text-slate-400 mt-1">Active utility grids</span>
            </div>
          </div>

          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 hover:border-indigo-500/30 transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-indigo-500/5 group">
            <div className="flex justify-between items-center">
              <span className="text-xs font-semibold uppercase text-slate-500 tracking-wider">Bills Generated</span>
              <div className="p-2.5 bg-indigo-950/30 border border-indigo-800/20 rounded-xl text-indigo-400 group-hover:scale-110 transition-transform">
                <FileText className="h-5 w-5" />
              </div>
            </div>
            <div className="mt-4">
              <span className="text-3xl font-extrabold font-mono">{totalBills}</span>
              <span className="text-xs block text-slate-400 mt-1">{paidBillsCount} paid / {totalBills - paidBillsCount} unpaid</span>
            </div>
          </div>

          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 hover:border-emerald-500/30 transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-emerald-500/5 group">
            <div className="flex justify-between items-center">
              <span className="text-xs font-semibold uppercase text-slate-500 tracking-wider">Revenue Collected</span>
              <div className="p-2.5 bg-emerald-950/30 border border-emerald-800/20 rounded-xl text-emerald-400 group-hover:scale-110 transition-transform">
                <DollarSign className="h-5 w-5" />
              </div>
            </div>
            <div className="mt-4">
              <span className="text-3xl font-extrabold font-mono text-emerald-400">${totalRevenue.toFixed(2)}</span>
              <span className="text-xs block text-slate-400 mt-1">Cleared invoices subtotal</span>
            </div>
          </div>

          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 hover:border-purple-500/30 transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-purple-500/5 group">
            <div className="flex justify-between items-center">
              <span className="text-xs font-semibold uppercase text-slate-500 tracking-wider">Grid Efficiency</span>
              <div className="p-2.5 bg-purple-950/30 border border-purple-800/20 rounded-xl text-purple-400 group-hover:scale-110 transition-transform">
                <Zap className="h-5 w-5" />
              </div>
            </div>
            <div className="mt-4">
              <span className="text-3xl font-extrabold font-mono">98.4%</span>
              <span className="text-xs block text-slate-400 mt-1">Simulated load factor</span>
            </div>
          </div>
        </section>

        {/* Input Form Area */}
        <section>
          <AdminBillGenerationForm />
        </section>

        {/* Listings */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 bg-slate-900/60 border border-slate-850 p-6 rounded-2xl">
            <div className="border-b border-slate-800 pb-3 mb-4">
              <h4 className="text-md font-bold text-slate-200">Customer Directory</h4>
            </div>
            <div className="space-y-3.5">
              {customers.map((c) => (
                <div key={c.id} className="flex items-center justify-between p-3.5 bg-slate-950/40 border border-slate-850 rounded-xl">
                  <div>
                    <h5 className="font-semibold text-slate-250 text-sm">{c.fullName}</h5>
                    <span className="text-[10px] text-slate-500 font-mono block mt-0.5">{c.connectionNumber} • Meter {c.meterNumber}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-slate-400 font-mono">{c.lastReading.toFixed(2)} kWh</span>
                    <span className="text-[9px] text-slate-600 block uppercase tracking-wider mt-0.5 font-medium">Last Reading</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-7 bg-slate-900/60 border border-slate-850 p-6 rounded-2xl">
            <div className="border-b border-slate-800 pb-3 mb-4 flex justify-between items-center">
              <h4 className="text-md font-bold text-slate-200">Invoice Generation Records</h4>
              <span className="text-xs text-slate-500 font-semibold">{bills.length} bills generated</span>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-500 text-xs uppercase tracking-wider font-semibold">
                    <th className="pb-3">Bill ID</th>
                    <th className="pb-3">Customer</th>
                    <th className="pb-3">Month</th>
                    <th className="pb-3">Total Amount</th>
                    <th className="pb-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {bills.map((b) => (
                    <tr key={b.id} className="text-slate-350">
                      <td className="py-3 font-mono text-xs text-indigo-400">#{b.id}</td>
                      <td className="py-3 font-medium text-slate-200">{b.customerName}</td>
                      <td className="py-3 font-mono text-xs">{b.billingMonth}</td>
                      <td className="py-3 font-semibold font-mono text-slate-200">${b.totalAmount.toFixed(2)}</td>
                      <td className="py-3">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase border ${
                          b.status === 'PAID' 
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        }`}>
                          {b.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {bills.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-slate-500 text-xs">
                        No bills created. Use the form above to generate your first invoice.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>

      {/* Simulated Notification Terminal Drawer */}
      {showLogs && (
        <div className="fixed bottom-0 left-0 right-0 h-80 bg-slate-950 border-t border-slate-800 z-50 flex flex-col shadow-2xl">
          <div className="bg-slate-900 px-5 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <Terminal className="h-4 w-4 text-cyan-400" />
              <span className="text-xs font-bold text-slate-350 tracking-wider uppercase">SMTP Mailer Console (Thread Pool Dispatcher)</span>
            </div>
            <button
              onClick={() => setShowLogs(false)}
              className="text-xs font-bold text-slate-500 hover:text-slate-350 transition cursor-pointer"
            >
              Close Console
            </button>
          </div>
          <div className="flex-1 p-5 font-mono text-xs overflow-y-auto space-y-3 bg-slate-950 text-slate-400 select-all scrollbar-thin">
            <div className="text-slate-500">// Starting virtual SMTP thread listening on localhost:1025...</div>
            <div className="text-slate-500">// Intercepting async event broadcasts of package 'com.utility.billing.service.NotificationService'</div>
            
            {notificationsLog.map((log) => (
              <div key={log.id} className="border-l-2 border-indigo-500 pl-3.5 py-1 animate-fadeIn bg-slate-900/10 rounded-r-md">
                <div className="flex items-center space-x-2 text-[10px]">
                  <span className="text-slate-500">[{log.timestamp}]</span>
                  {log.status === 'SENT' ? (
                    <span className="text-emerald-400 font-bold flex items-center space-x-1">
                      <CheckCircle2 className="h-3 w-3 inline" />
                      <span>[ASYNC-THREAD-OK]</span>
                    </span>
                  ) : (
                    <span className="text-amber-400 font-bold flex items-center space-x-1 animate-pulse">
                      <Clock className="h-3 w-3 inline" />
                      <span>[DISPATCHING...]</span>
                    </span>
                  )}
                  <span className="text-cyan-400">To: {log.recipient}</span>
                </div>
                <div className="text-slate-350 font-bold mt-1 text-[11px]">{log.title}</div>
                <div className="text-slate-455 text-[11px] mt-0.5">{log.body}</div>
              </div>
            ))}

            {notificationsLog.length === 0 && (
              <div className="text-slate-600 text-center py-6">
                No notification tasks in thread pool. Generate bills or pay bills to trigger emails.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
