import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Zap, CreditCard, Download, CheckCircle, HelpCircle, Lock, LogOut } from 'lucide-react';

export const CustomerDashboard = () => {
  const { user, bills, customers, payBill, logout } = useApp();
  
  // Resolve profile dynamically based on active user session email
  const profile = React.useMemo(() => {
    if (!user) return null;
    if (user.email === 'customer@utility.com') {
      return customers.find(c => c.id === 101) || customers[0];
    }
    const registeredUsers = JSON.parse(localStorage.getItem('users') || '[]');
    const matchedUser = registeredUsers.find(u => u.email === user.email);
    if (matchedUser) {
      return customers.find(c => c.id === matchedUser.profileId) || customers[0];
    }
    return customers[0];
  }, [user, customers]);

  const customerBills = bills.filter(b => b.customerId === profile?.id);
  const unpaidBills = customerBills.filter(b => b.status === 'UNPAID');
  
  const outstandingAmount = unpaidBills.reduce((sum, b) => sum + b.totalAmount, 0);

  const [checkoutBill, setCheckoutBill] = useState(null);
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [isFlipped, setIsFlipped] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [txRef, setTxRef] = useState('');
  
  const [downloadingId, setDownloadingId] = useState(null);

  const handleOpenCheckout = (bill) => {
    setCheckoutBill(bill);
    setCardNumber('');
    setCardName('');
    setCardExpiry('');
    setCardCvv('');
    setIsFlipped(false);
    setPaymentSuccess(false);
    setTxRef('');
  };

  const handlePaySubmit = (e) => {
    e.preventDefault();
    if (!checkoutBill) return;

    setProcessing(true);
    setTimeout(() => {
      try {
        const payment = payBill(checkoutBill.id, 'CREDIT_CARD');
        setTxRef(payment.transactionReference);
        setPaymentSuccess(true);
      } catch (err) {
        alert('Payment failed');
      } finally {
        setProcessing(false);
      }
    }, 2000);
  };

  const handlePdfDownload = (bill) => {
    setDownloadingId(bill.id);
    setTimeout(() => {
      setDownloadingId(null);
      alert(`SUCCESS: Simulated PDF Invoice downloaded.\n\nVoltStream Billing invoice #${bill.id}\nMonth: ${bill.billingMonth}\nCustomer: ${profile.fullName}\nTotal Due: $${bill.totalAmount.toFixed(2)}`);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Navbar */}
      <nav className="glass border-b border-slate-800/80 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 bg-gradient-to-tr from-cyan-400 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/10">
            <Zap className="h-5 w-5 text-slate-950 fill-slate-950 stroke-[1.5]" />
          </div>
          <div>
            <span className="font-extrabold text-white tracking-tight text-lg">VoltStream</span>
            <span className="ml-2.5 bg-indigo-500/15 text-indigo-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-indigo-500/20">
              ROLE_CUSTOMER
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <span className="text-slate-400 text-sm hidden md:inline">{user?.email}</span>
          <button
            onClick={logout}
            className="flex items-center space-x-1.5 py-2 px-4 text-xs font-bold bg-slate-900 border border-slate-800 hover:border-red-500/50 hover:bg-red-950/20 hover:text-red-300 rounded-xl transition-all cursor-pointer"
          >
            <LogOut className="h-4 w-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </nav>

      {/* Main dashboard content */}
      <main className="flex-1 p-6 md:p-8 max-w-6xl w-full mx-auto space-y-8 animate-fadeIn">
        
        {/* Customer Account Details banner */}
        <section className="grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch">
          <div className="md:col-span-8 bg-slate-900/40 border border-slate-800/80 rounded-2xl p-6 flex flex-col justify-between shadow-lg">
            <div>
              <span className="text-[10px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
                Connection Registered
              </span>
              <h2 className="text-2xl font-extrabold mt-3 text-slate-100">{profile?.fullName}</h2>
              <p className="text-slate-450 text-xs mt-1">{profile?.address}</p>
            </div>
            
            <div className="grid grid-cols-3 gap-4 mt-6 border-t border-slate-800/60 pt-5 text-xs">
              <div>
                <span className="text-slate-500 uppercase tracking-wider block font-semibold">Account ID</span>
                <span className="text-slate-300 font-mono mt-0.5 block">{profile?.connectionNumber}</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase tracking-wider block font-semibold">Meter Serial</span>
                <span className="text-slate-300 font-mono mt-0.5 block">{profile?.meterNumber}</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase tracking-wider block font-semibold">Baseline kWh</span>
                <span className="text-slate-300 font-mono mt-0.5 block">{profile?.lastReading.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="md:col-span-4 bg-gradient-to-br from-indigo-950/30 to-slate-900/30 border border-indigo-900/40 rounded-2xl p-6 flex flex-col justify-between shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-2xl" />
            
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold block">Total Outstanding Balance</span>
              <h3 className={`text-4xl font-black mt-2 font-mono ${outstandingAmount > 0 ? 'text-indigo-400' : 'text-emerald-400'}`}>
                ${outstandingAmount.toFixed(2)}
              </h3>
            </div>

            <div className="mt-6">
              {unpaidBills.length > 0 ? (
                <div className="text-xs bg-indigo-950/20 border border-indigo-900/30 p-3.5 rounded-xl text-slate-300">
                  <span className="font-semibold block mb-0.5">Next Invoice Pending</span>
                  <span>Due Date: {unpaidBills[0].dueDate}</span>
                </div>
              ) : (
                <div className="text-xs bg-emerald-950/20 border border-emerald-900/30 p-3.5 rounded-xl text-emerald-400">
                  <span>✓ All clear! You have no outstanding bills.</span>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* 3D Gauge + Consumption Chart Row */}
        <section className="grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-5 bg-slate-900/40 border border-slate-800/80 p-6 rounded-2xl flex flex-col justify-between items-center text-center">
            <div className="w-full border-b border-slate-800 pb-3 text-left">
              <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">Dynamic Energy Gauge</h4>
            </div>
            
            <div className="relative w-44 h-44 flex items-center justify-center mt-6">
              <div className="absolute inset-0 rounded-full border border-slate-800 flex items-center justify-center">
                <div className="w-36 h-36 rounded-full border border-indigo-500/10 glow-indigo" />
              </div>
              
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="88"
                  cy="88"
                  r="72"
                  className="stroke-slate-850 fill-transparent"
                  strokeWidth="8"
                />
                <circle
                  cx="88"
                  cy="88"
                  r="72"
                  className="stroke-indigo-500 fill-transparent transition-all duration-1000"
                  strokeWidth="8"
                  strokeDasharray="452.4"
                  strokeDashoffset={452.4 - (Math.min(profile?.lastReading || 0, 5000) / 5000) * 452.4}
                  strokeLinecap="round"
                />
              </svg>
              
              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-2xl font-black font-mono text-white">{profile?.lastReading.toFixed(0)}</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold mt-1">Total kWh Used</span>
              </div>
            </div>

            <p className="text-[10px] text-slate-500 mt-6 max-w-xs">
              This dial visualizes cumulative consumption relative to your local residential grid baseline.
            </p>
          </div>

          <div className="md:col-span-7 bg-slate-900/40 border border-slate-800/80 p-6 rounded-2xl">
            <div className="border-b border-slate-800 pb-3 mb-4 flex justify-between items-center">
              <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">Invoices Ledger</h4>
              <span className="text-xs text-slate-500">{customerBills.length} records</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-500 text-xs uppercase tracking-wider font-semibold">
                    <th className="pb-3">Month</th>
                    <th className="pb-3">Amount Due</th>
                    <th className="pb-3">Due Date</th>
                    <th className="pb-3 text-center">Status</th>
                    <th className="pb-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {customerBills.map((b) => (
                    <tr key={b.id} className="text-slate-350">
                      <td className="py-3.5 font-mono text-xs text-slate-200">{b.billingMonth}</td>
                      <td className="py-3.5 font-semibold font-mono text-slate-100">${b.totalAmount.toFixed(2)}</td>
                      <td className="py-3.5 font-mono text-xs">{b.dueDate}</td>
                      <td className="py-3.5 text-center">
                        <span className={`text-[9px] font-extrabold px-2.5 py-0.5 rounded-full uppercase border ${
                          b.status === 'PAID'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        }`}>
                          {b.status}
                        </span>
                      </td>
                      <td className="py-3.5 text-right space-x-2">
                        <button
                          onClick={() => handlePdfDownload(b)}
                          disabled={downloadingId === b.id}
                          className="p-1.5 rounded-lg border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 bg-slate-900/30 transition cursor-pointer disabled:opacity-40"
                          title="Download Invoice PDF"
                        >
                          {downloadingId === b.id ? (
                            <svg className="animate-spin h-3.5 w-3.5 text-slate-450" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                            </svg>
                          ) : (
                            <Download className="h-3.5 w-3.5" />
                          )}
                        </button>
                        {b.status === 'UNPAID' && (
                          <button
                            onClick={() => handleOpenCheckout(b)}
                            className="text-xs bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-1.5 px-3 rounded-lg shadow-md transition-all transform hover:-translate-y-0.5 cursor-pointer active:translate-y-0"
                          >
                            Pay Now
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {customerBills.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-500 text-xs">
                        No invoices registered for this connection number.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>

      {/* 3D Payment Drawer Overlay */}
      {checkoutBill && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl animate-fadeIn relative">
            <button
              onClick={() => setCheckoutBill(null)}
              className="absolute top-4 right-4 text-slate-500 hover:text-slate-350 cursor-pointer"
            >
              ✕
            </button>

            {!paymentSuccess ? (
              <form onSubmit={handlePaySubmit} className="space-y-6">
                <div>
                  <h3 className="text-lg font-black text-slate-100">Secure Payment Checkout</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Pay Bill Reference Invoice #{checkoutBill.id}</p>
                </div>

                {/* 3D CREDIT CARD */}
                <div className="w-full h-44 perspective-1000 my-4 select-none">
                  <div 
                    className={`w-full h-full rounded-2xl relative transition-transform duration-700 transform-style-3d cursor-pointer ${
                      isFlipped ? 'rotate-y-180' : ''
                    }`}
                    onClick={() => setIsFlipped(!isFlipped)}
                  >
                    <div className="backface-hidden absolute inset-0 bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-500 rounded-2xl p-5 flex flex-col justify-between shadow-2xl">
                      <div className="flex justify-between items-start">
                        <div className="flex flex-col">
                          <span className="text-[9px] uppercase tracking-widest text-indigo-100 font-medium">VoltStream Card</span>
                          <CreditCard className="h-7 w-7 text-indigo-100 mt-1" />
                        </div>
                        <span className="text-xs font-mono font-bold text-white bg-slate-950/20 px-2 py-0.5 rounded">VISA</span>
                      </div>

                      <div className="text-lg font-mono tracking-widest text-white text-center py-2 truncate">
                        {cardNumber || '••••  ••••  ••••  ••••'}
                      </div>

                      <div className="flex justify-between text-xs font-mono">
                        <div>
                          <span className="text-[8px] uppercase tracking-wider block text-indigo-200">Cardholder</span>
                          <span className="text-white truncate block max-w-[150px] uppercase font-bold">{cardName || 'YOUR FULL NAME'}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[8px] uppercase tracking-wider block text-indigo-200">Expires</span>
                          <span className="text-white font-bold">{cardExpiry || 'MM/YY'}</span>
                        </div>
                      </div>
                    </div>

                    <div className="backface-hidden rotate-y-180 absolute inset-0 bg-slate-800 rounded-2xl flex flex-col justify-between border border-slate-700 shadow-2xl py-5">
                      <div className="w-full bg-slate-950 h-9" />
                      
                      <div className="px-5 grid grid-cols-12 gap-2 items-center">
                        <div className="col-span-8 bg-slate-100 h-6 flex items-center justify-end px-3 rounded shadow-inner">
                          <span className="text-slate-450 italic font-mono text-[10px]">Authorized Signature</span>
                        </div>
                        <div className="col-span-4 bg-amber-100/10 border border-amber-500/20 rounded p-1 text-center">
                          <span className="text-white font-mono text-xs font-bold">{cardCvv || 'CVV'}</span>
                        </div>
                      </div>

                      <div className="px-5 flex justify-between items-center text-[8px] font-mono text-slate-500">
                        <span className="text-left leading-tight">VoltStream Crypt\nGateway (Stateless 256-bit SSL)</span>
                        <span className="font-bold">CVV REQUIRED</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 text-xs">
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider font-semibold text-slate-400 mb-1">Cardholder Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Jane Doe"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      onFocus={() => setIsFlipped(false)}
                      className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 outline-none text-slate-200 font-medium px-3.5 py-2 rounded-xl transition"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-wider font-semibold text-slate-400 mb-1">Card Number</label>
                    <input
                      type="text"
                      required
                      maxLength={19}
                      placeholder="4000 1234 5678 9010"
                      value={cardNumber}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
                        const matches = val.match(/\d{4,16}/g);
                        const match = (matches && matches[0]) || '';
                        const parts = [];
                        for (let i = 0, len = match.length; i < len; i += 4) {
                          parts.push(match.substring(i, i + 4));
                        }
                        if (parts.length > 0) {
                          setCardNumber(parts.join('  '));
                        } else {
                          setCardNumber(e.target.value);
                        }
                      }}
                      onFocus={() => setIsFlipped(false)}
                      className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 outline-none text-slate-200 font-mono px-3.5 py-2 rounded-xl transition"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider font-semibold text-slate-400 mb-1">Expiry Date</label>
                      <input
                        type="text"
                        required
                        maxLength={5}
                        placeholder="MM/YY"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        onFocus={() => setIsFlipped(false)}
                        className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 outline-none text-slate-200 font-mono px-3.5 py-2 rounded-xl transition"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider font-semibold text-slate-400 mb-1">CVV Code</label>
                      <input
                        type="password"
                        required
                        maxLength={3}
                        placeholder="•••"
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        onFocus={() => setIsFlipped(true)}
                        onBlur={() => setIsFlipped(false)}
                        className="w-full bg-slate-950/60 border border-slate-800 focus:border-indigo-500 outline-none text-slate-200 font-mono px-3.5 py-2 rounded-xl transition"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={processing}
                  className="w-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-600 hover:from-cyan-600 hover:via-indigo-600 hover:to-purple-700 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg transition duration-200 transform active:scale-98 disabled:opacity-40 disabled:pointer-events-none"
                >
                  {processing ? (
                    <span className="flex items-center justify-center space-x-2">
                      <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Authenticating Card...</span>
                    </span>
                  ) : (
                    `Pay $${checkoutBill.totalAmount.toFixed(2)} Invoice`
                  )}
                </button>

                <div className="flex items-center justify-center space-x-2 text-[10px] text-slate-500 pt-2 border-t border-slate-855">
                  <Lock className="h-3 w-3 text-cyan-400" />
                  <span>256-Bit SSL Encrypted Ledger Gateway Connection</span>
                </div>
              </form>
            ) : (
              <div className="text-center py-8 space-y-5 animate-fadeIn">
                <div className="mx-auto w-14 h-14 bg-emerald-950/40 border border-emerald-900/60 rounded-full flex items-center justify-center text-emerald-400 animate-bounce">
                  <CheckCircle className="h-8 w-8" />
                </div>

                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-slate-100">Payment Cleared Successfully</h3>
                  <p className="text-xs text-slate-400">Your invoice has been updated. Simulated receipt has been processed.</p>
                </div>

                <div className="bg-slate-950/40 border border-slate-850 p-4 rounded-2xl text-xs space-y-2 text-left max-w-sm mx-auto font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Invoice ID</span>
                    <span className="text-slate-300">#{checkoutBill.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Transaction Ref</span>
                    <span className="text-slate-300">{txRef}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Amount Settled</span>
                    <span className="text-emerald-400 font-bold">${checkoutBill.totalAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Payment Mode</span>
                    <span className="text-slate-300">CREDIT CARD</span>
                  </div>
                </div>

                <button
                  onClick={() => setCheckoutBill(null)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold py-2 px-6 rounded-xl border border-slate-750 transition"
                >
                  Return to Dashboard
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerDashboard;
