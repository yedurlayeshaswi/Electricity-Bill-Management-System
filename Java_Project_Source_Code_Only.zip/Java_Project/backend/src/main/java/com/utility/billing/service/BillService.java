package com.utility.billing.service;

import com.utility.billing.dto.BillGenerationRequest;
import com.utility.billing.dto.BillResponse;
import com.utility.billing.model.Bill;
import com.utility.billing.model.CustomerProfile;
import com.utility.billing.model.MeterReading;
import com.utility.billing.repository.BillRepository;
import com.utility.billing.repository.CustomerProfileRepository;
import com.utility.billing.repository.MeterReadingRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BillService {

    private final CustomerProfileRepository customerRepository;
    private final MeterReadingRepository readingRepository;
    private final BillRepository billRepository;
    private final BillCalculationService calculationService;
    private final NotificationService notificationService;

    public BillService(CustomerProfileRepository customerRepository,
                       MeterReadingRepository readingRepository,
                       BillRepository billRepository,
                       BillCalculationService calculationService,
                       NotificationService notificationService) {
        this.customerRepository = customerRepository;
        this.readingRepository = readingRepository;
        this.billRepository = billRepository;
        this.calculationService = calculationService;
        this.notificationService = notificationService;
    }

    /**
     * Generates a bill, saves it, and sends asynchronous notification.
     */
    @Transactional
    public BillResponse generateBill(BillGenerationRequest request) {
        // 1. Guard against duplicate bills for the same month/customer
        if (billRepository.existsByCustomerIdAndBillingMonth(request.getCustomerId(), request.getBillingMonth())) {
            throw new IllegalStateException("A bill has already been generated for this customer for the month: " + request.getBillingMonth());
        }

        // 2. Fetch dependencies
        CustomerProfile customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new IllegalArgumentException("Customer profile not found with ID: " + request.getCustomerId()));

        MeterReading reading = readingRepository.findById(request.getReadingId())
                .orElseThrow(() -> new IllegalArgumentException("Meter reading not found with ID: " + request.getReadingId()));

        // 3. Confirm reading belongs to customer
        if (!reading.getCustomer().getId().equals(customer.getId())) {
            throw new IllegalArgumentException("The specified meter reading does not belong to the selected customer");
        }

        // 4. Calculate bill fields using dynamic tiered logic
        Bill bill = calculationService.calculateBill(customer, reading, request.getBillingMonth(), request.getDueDate());

        // 5. Persist to DB
        Bill savedBill = billRepository.save(bill);

        // 6. Trigger async email notification
        notificationService.sendBillGeneratedNotification(savedBill);

        return new BillResponse(savedBill);
    }
}
