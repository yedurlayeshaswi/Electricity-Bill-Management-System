package com.utility.billing.service;

import com.utility.billing.model.Bill;
import com.utility.billing.model.BillStatus;
import com.utility.billing.model.CustomerProfile;
import com.utility.billing.model.MeterReading;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

@Service
public class BillCalculationService {

    // Tiered Billing Rates and Limits according to specifications
    private static final BigDecimal BASE_FIXED_CHARGE = new BigDecimal("10.00");
    private static final BigDecimal TIER_1_LIMIT = new BigDecimal("100.00");
    private static final BigDecimal TIER_2_LIMIT = new BigDecimal("300.00");

    private static final BigDecimal TIER_1_RATE = new BigDecimal("0.12"); // 0 - 100 kWh
    private static final BigDecimal TIER_2_RATE = new BigDecimal("0.18"); // 101 - 300 kWh
    private static final BigDecimal TIER_3_RATE = new BigDecimal("0.25"); // 301+ kWh

    private static final BigDecimal UTILITY_TAX_RATE = new BigDecimal("0.05"); // 5% Utility Tax

    /**
     * Calculates the electricity bill based on base charge, tiered usage, and taxes.
     */
    public Bill calculateBill(CustomerProfile customer, MeterReading reading, String billingMonth, LocalDate dueDate) {
        BigDecimal totalUnits = reading.getTotalUnits();
        if (totalUnits == null || totalUnits.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Total units consumed cannot be null or negative");
        }

        BigDecimal tieredConsumptionCost = calculateTieredConsumptionCost(totalUnits);
        
        // Base Charge + Tiered Consumption Cost
        BigDecimal amountDue = BASE_FIXED_CHARGE.add(tieredConsumptionCost).setScale(2, RoundingMode.HALF_UP);
        
        // 5% utility tax on (Base Charge + Tiered Consumption Cost)
        BigDecimal taxAmount = amountDue.multiply(UTILITY_TAX_RATE).setScale(2, RoundingMode.HALF_UP);
        
        // Total bill amount including tax
        BigDecimal totalAmount = amountDue.add(taxAmount).setScale(2, RoundingMode.HALF_UP);

        Bill bill = new Bill();
        bill.setCustomer(customer);
        bill.setMeterReading(reading);
        bill.setBillingMonth(billingMonth);
        bill.setAmountDue(amountDue);
        bill.setTaxAmount(taxAmount);
        bill.setTotalAmount(totalAmount);
        bill.setDueDate(dueDate);
        bill.setStatus(BillStatus.UNPAID);

        return bill;
    }

    /**
     * Performs tiered rate split calculation.
     */
    private BigDecimal calculateTieredConsumptionCost(BigDecimal units) {
        BigDecimal cost = BigDecimal.ZERO;

        if (units.compareTo(TIER_1_LIMIT) <= 0) {
            // All units are in Tier 1 (0 to 100 kWh)
            cost = units.multiply(TIER_1_RATE);
        } else if (units.compareTo(TIER_2_LIMIT) <= 0) {
            // First 100 units in Tier 1, rest in Tier 2 (101 to 300 kWh)
            BigDecimal tier1Cost = TIER_1_LIMIT.multiply(TIER_1_RATE);
            BigDecimal tier2Units = units.subtract(TIER_1_LIMIT);
            BigDecimal tier2Cost = tier2Units.multiply(TIER_2_RATE);
            cost = tier1Cost.add(tier2Cost);
        } else {
            // First 100 units in Tier 1, next 200 in Tier 2, rest in Tier 3 (301+ kWh)
            BigDecimal tier1Cost = TIER_1_LIMIT.multiply(TIER_1_RATE);
            BigDecimal tier2Range = TIER_2_LIMIT.subtract(TIER_1_LIMIT); // 200 kWh
            BigDecimal tier2Cost = tier2Range.multiply(TIER_2_RATE);
            BigDecimal tier3Units = units.subtract(TIER_2_LIMIT);
            BigDecimal tier3Cost = tier3Units.multiply(TIER_3_RATE);
            cost = tier1Cost.add(tier2Cost).add(tier3Cost);
        }

        return cost.setScale(2, RoundingMode.HALF_UP);
    }
}
