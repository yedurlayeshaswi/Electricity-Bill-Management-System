package com.utility.billing.dto;

import com.utility.billing.model.Bill;
import com.utility.billing.model.BillStatus;

import java.math.BigDecimal;
import java.time.LocalDate;

public class BillResponse {

    private Long id;
    private Long customerId;
    private String connectionNumber;
    private String meterNumber;
    private BigDecimal totalUnits;
    private BigDecimal amountDue;
    private BigDecimal taxAmount;
    private BigDecimal totalAmount;
    private String billingMonth;
    private LocalDate dueDate;
    private BillStatus status;

    public BillResponse() {
    }

    public BillResponse(Bill bill) {
        this.id = bill.getId();
        this.customerId = bill.getCustomer().getId();
        this.connectionNumber = bill.getCustomer().getConnectionNumber();
        this.meterNumber = bill.getCustomer().getMeterNumber();
        this.totalUnits = bill.getMeterReading().getTotalUnits();
        this.amountDue = bill.getAmountDue();
        this.taxAmount = bill.getTaxAmount();
        this.totalAmount = bill.getTotalAmount();
        this.billingMonth = bill.getBillingMonth();
        this.dueDate = bill.getDueDate();
        this.status = bill.getStatus();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getConnectionNumber() {
        return connectionNumber;
    }

    public void setConnectionNumber(String connectionNumber) {
        this.connectionNumber = connectionNumber;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }

    public BigDecimal getTotalUnits() {
        return totalUnits;
    }

    public void setTotalUnits(BigDecimal totalUnits) {
        this.totalUnits = totalUnits;
    }

    public BigDecimal getAmountDue() {
        return amountDue;
    }

    public void setAmountDue(BigDecimal amountDue) {
        this.amountDue = amountDue;
    }

    public BigDecimal getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(BigDecimal taxAmount) {
        this.taxAmount = taxAmount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getBillingMonth() {
        return billingMonth;
    }

    public void setBillingMonth(String billingMonth) {
        this.billingMonth = billingMonth;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public BillStatus getStatus() {
        return status;
    }

    public void setStatus(BillStatus status) {
        this.status = status;
    }
}
