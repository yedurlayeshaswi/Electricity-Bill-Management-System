package com.utility.billing.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDate;

public class BillGenerationRequest {

    @NotNull(message = "Customer ID is required")
    private Long customerId;

    @NotNull(message = "Meter reading ID is required")
    private Long readingId;

    @NotNull(message = "Billing month is required")
    @Pattern(regexp = "^\\d{4}-(0[1-9]|1[0-2])$", message = "Billing month must be in YYYY-MM format (e.g. 2026-07)")
    private String billingMonth;

    @NotNull(message = "Due date is required")
    private LocalDate dueDate;

    public BillGenerationRequest() {
    }

    public BillGenerationRequest(Long customerId, Long readingId, String billingMonth, LocalDate dueDate) {
        this.customerId = customerId;
        this.readingId = readingId;
        this.billingMonth = billingMonth;
        this.dueDate = dueDate;
    }

    // Getters and Setters
    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getReadingId() {
        return readingId;
    }

    public void setReadingId(Long readingId) {
        this.readingId = readingId;
    }

    public String getBillingMonth() {
        return billingMonth;
    }

    public void setBillingMonth(String billingMonth) {
        this.billingMonth = billingMonth;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }
}
