package com.utility.billing.repository;

import com.utility.billing.model.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BillRepository extends JpaRepository<Bill, Long> {
    boolean existsByCustomerIdAndBillingMonth(Long customerId, String billingMonth);
}
