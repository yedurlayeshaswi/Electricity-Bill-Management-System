package com.utility.billing.model;

public enum Role {
    ROLE_ADMIN,
    ROLE_CUSTOMER
}
