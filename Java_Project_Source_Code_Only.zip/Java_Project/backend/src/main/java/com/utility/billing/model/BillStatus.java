package com.utility.billing.model;

public enum BillStatus {
    UNPAID,
    PAID,
    OVERDUE
}
