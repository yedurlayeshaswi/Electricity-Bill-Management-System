package com.utility.billing.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "meter_readings")
public class MeterReading {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    @NotNull(message = "Customer reference is required")
    private CustomerProfile customer;

    @Column(name = "reading_date", nullable = false)
    @NotNull(message = "Reading date is required")
    private LocalDate readingDate;

    @Column(name = "previous_reading", nullable = false, precision = 10, scale = 2)
    @NotNull(message = "Previous reading is required")
    @DecimalMin(value = "0.00", message = "Previous reading cannot be negative")
    private BigDecimal previousReading;

    @Column(name = "current_reading", nullable = false, precision = 10, scale = 2)
    @NotNull(message = "Current reading is required")
    @DecimalMin(value = "0.00", message = "Current reading cannot be negative")
    private BigDecimal currentReading;

    @Column(name = "total_units", nullable = false, precision = 10, scale = 2)
    @NotNull(message = "Total units is required")
    @DecimalMin(value = "0.00", message = "Total units cannot be negative")
    private BigDecimal totalUnits;

    public MeterReading() {
    }

    public MeterReading(CustomerProfile customer, LocalDate readingDate, BigDecimal previousReading, BigDecimal currentReading) {
        this.customer = customer;
        this.readingDate = readingDate;
        this.previousReading = previousReading;
        this.currentReading = currentReading;
        this.totalUnits = currentReading.subtract(previousReading);
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public CustomerProfile getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerProfile customer) {
        this.customer = customer;
    }

    public LocalDate getReadingDate() {
        return readingDate;
    }

    public void setReadingDate(LocalDate readingDate) {
        this.readingDate = readingDate;
    }

    public BigDecimal getPreviousReading() {
        return previousReading;
    }

    public void setPreviousReading(BigDecimal previousReading) {
        this.previousReading = previousReading;
    }

    public BigDecimal getCurrentReading() {
        return currentReading;
    }

    public void setCurrentReading(BigDecimal currentReading) {
        this.currentReading = currentReading;
        if (this.previousReading != null) {
            this.totalUnits = currentReading.subtract(this.previousReading);
        }
    }

    public BigDecimal getTotalUnits() {
        return totalUnits;
    }

    public void setTotalUnits(BigDecimal totalUnits) {
        this.totalUnits = totalUnits;
    }
}
