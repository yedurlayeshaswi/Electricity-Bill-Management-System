package com.utility.billing.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(
    name = "customer_profiles",
    uniqueConstraints = {
        @UniqueConstraint(columnNames = {"user_id"}),
        @UniqueConstraint(columnNames = {"connection_number"}),
        @UniqueConstraint(columnNames = {"meter_number"})
    }
)
public class CustomerProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    @NotNull(message = "User reference cannot be null")
    private User user;

    @Column(name = "connection_number", nullable = false, unique = true, length = 50)
    @NotNull(message = "Connection number is required")
    @Size(min = 5, max = 50, message = "Connection number must be between 5 and 50 characters")
    private String connectionNumber;

    @Column(name = "address", nullable = false, columnDefinition = "TEXT")
    @NotNull(message = "Billing address is required")
    private String address;

    @Column(name = "meter_number", nullable = false, unique = true, length = 50)
    @NotNull(message = "Meter number is required")
    @Size(min = 5, max = 50, message = "Meter number must be between 5 and 50 characters")
    private String meterNumber;

    public CustomerProfile() {
    }

    public CustomerProfile(User user, String connectionNumber, String address, String meterNumber) {
        this.user = user;
        this.connectionNumber = connectionNumber;
        this.address = address;
        this.meterNumber = meterNumber;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getConnectionNumber() {
        return connectionNumber;
    }

    public void setConnectionNumber(String connectionNumber) {
        this.connectionNumber = connectionNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }
}
