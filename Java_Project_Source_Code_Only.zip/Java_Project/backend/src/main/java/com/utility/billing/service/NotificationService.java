package com.utility.billing.service;

import com.utility.billing.model.Bill;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

    /**
     * Sends an email notification asynchronously when a bill is generated.
     */
    @Async
    public void sendBillGeneratedNotification(Bill bill) {
        logger.info("Starting async notification dispatch thread for Bill ID: {}", bill.getId());
        try {
            // Mock network delay (e.g. SMTP connection and dispatch)
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Async notification dispatch interrupted", e);
            return;
        }

        String recipientEmail = bill.getCustomer().getUser().getEmail();
        logger.info("SUCCESS: Electricity bill notification dispatched asynchronously to customer email: [{}]. Month: [{}], Amount: [${}]",
                recipientEmail, bill.getBillingMonth(), bill.getTotalAmount());
    }

    /**
     * Sends a payment confirmation notification asynchronously.
     */
    @Async
    public void sendPaymentConfirmationNotification(Bill bill, String txRef) {
        logger.info("Starting async payment notification dispatch thread for Bill ID: {}", bill.getId());
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Async payment notification dispatch interrupted", e);
            return;
        }

        String recipientEmail = bill.getCustomer().getUser().getEmail();
        logger.info("SUCCESS: Payment confirmation dispatched asynchronously to customer email: [{}]. Transaction Ref: [{}], Amount: [${}]",
                recipientEmail, txRef, bill.getTotalAmount());
    }
}
