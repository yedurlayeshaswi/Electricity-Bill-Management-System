# VoltStream: Electricity Bill Management System

VoltStream is a secure, scalable, and modern Electricity Bill Management System built using **Spring Boot 3.x** for the backend, **React 18** (Vite + TypeScript) for the frontend, and a **MySQL** database.

The application includes a client-side **Dual-Mode Data Simulator** using `localStorage` so you can interact with and test all functionalities *immediately in your browser* without needing a local MySQL server running. It automatically switches to live backend APIs when it detects the Spring Boot server.

---

## ⚡ Tech Stack Specifications

*   **Backend:** Spring Boot 3.x, Java 17+, Spring Security 6 (Stateless Session Control), Spring Data JPA, Hibernate, Jakarta Validation API, MySQL Connector.
*   **Frontend:** React 18, Vite, TypeScript, Axios (with authorization interceptors), Tailwind CSS v4, Lucide Icons, and 3D transition layers.

---

## 🛠️ Key Architectural Features

### 1. Role-Based Access Control (RBAC)
*   **ROLE_ADMIN (Quick Access: `admin@utility.com` / `admin`):**
    *   Accesses the Global Analytics Dashboard (stats on customer connections, bill generations, and collected revenues).
    *   Enters monthly meter readings (checks current vs. previous baselines).
    *   Launches invoice generation.
    *   Tracks asynchronous background task queues (e.g., SMTP dispatch threads).
*   **ROLE_CUSTOMER (Quick Access: `customer@utility.com` / `customer`):**
    *   Checks connections, billing address, and baseline power limits.
    *   Tracks outstanding invoices and due deadlines.
    *   Downloads compiled monthly statement receipts (simulated PDF invoices).
    *   Pays outstanding balances securely using the **3D Interactive Credit Card Checkout module**.

### 2. Dynamic Tiered Billing Logic
The billing module automatically calculates charges based on standard utility steps:
*   **Base Connection Charge:** $10.00 (applied to all active connections)
*   **Tier 1 (0 - 100 kWh):** $0.12 per kWh
*   **Tier 2 (101 - 300 kWh):** $0.18 per kWh
*   **Tier 3 (301+ kWh):** $0.25 per kWh
*   **Utility Tax:** 5.0% added on subtotal (Base Charge + Tiered Consumption Cost).

### 3. Asynchronous Process Mocking
When bills are generated or paid, the backend (and simulated client side) launches email dispatches on separate thread pools. A dedicated **SMTP mailer console drawer** at the bottom of the Admin Dashboard flashes notifications and displays background thread execution logs (showing async delays).

---

## 🚀 Running the Application Locally

### 1. Spring Boot Backend Setup
1.  Ensure you have **Java 17+** and **Maven** installed.
2.  Install and start your local **MySQL Server**.
3.  Configure database credentials in `backend/src/main/resources/application.yml` (default is root / password).
4.  Run the application using Maven:
    ```bash
    cd backend
    mvn spring-boot:run
    ```
    *The system automatically boots up, creates the `electricity_db` schema, and updates the database tables.*

### 2. React Frontend Setup
1.  Ensure you have **Node.js** (v18+) and **npm** installed.
2.  Install dependencies:
    ```bash
    cd frontend
    npm install
    ```
3.  Run the Vite development server:
    ```bash
    npm run dev
    ```
4.  Open your browser at the local port (usually `http://localhost:3000`).

---

## 🎨 Interactive 3D Payment Experience
When logged in as a Customer, click **Pay Now** on any unpaid invoice:
1.  A checkout modal opens, displaying a **3D credit card**.
2.  Fill in the cardholder name, card number, and expiry date.
3.  **The 3D Animation:** Focus on the **CVV Code** input field. The credit card immediately executes a 3D flip (`rotateY(180deg)`) in the interface, revealing the signature strip and CVV bubble on the back of the card. Focus back on other fields to flip it to the front.
4.  Click **Pay** to process. A loading state animates, updates database states, and triggers the asynchronous mailer dispatch.
